# -*- coding: ISO-8859-1 -*-
"""Resource _cvsignore (from file .cvsignore)"""
# written by resourcepackage: (1, 0, 0)
source = '.cvsignore'
package = 'spambayes.languages.es'
data = "*.pyc\012*.pyo\012_cvsignore.py"
### end
