# -*- coding: ISO-8859-1 -*-
"""Resource _cvsignore (from file .cvsignore)"""
# written by resourcepackage: (1, 0, 0)
source = '.cvsignore'
package = 'spambayes.resources'
data = "*.pyc\012_cvsignore.py\012"
### end
