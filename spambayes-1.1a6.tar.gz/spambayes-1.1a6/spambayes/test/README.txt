This is a directory for unit tests of spambayes itself.
It is NOT to test the performance of the classification algorithms,
but tests the semantics of the infrastructure.
