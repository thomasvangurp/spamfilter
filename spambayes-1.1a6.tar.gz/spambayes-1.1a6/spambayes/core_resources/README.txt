When running SpamBayes from source, you need to install resourcepackage
from http://resourcepackage.sourceforge.net/ in order for your changes to
anything in the "resource" directory to take effect.  Download
ResourcePackage-1.0.0.tar.gz, unpack it into a temporary area, cd to that
area, and run "python setup.py install".  You can then delete the unpacked
files.
