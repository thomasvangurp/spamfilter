This directory contains a collection of spambayes applications/scripts.

Each file within this directory should be executable, and perform a specific task
(export the database, launch a POP3 proxy, and so on).

To avoid polluting the end user's python/scripts directory when spambayes is installed,
each script should be prefixed with 'sb_'.