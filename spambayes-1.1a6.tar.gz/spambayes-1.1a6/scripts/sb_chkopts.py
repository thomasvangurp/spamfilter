#!/usr/bin/env python

"""
Trivial script to check that the user's options file doesn't contain any
old-style option names.
"""

from spambayes import Options
